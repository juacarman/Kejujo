import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {FormBuilder} from '@angular/forms';
import {ReportesService} from './servicios/reportes.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'integrador2019';

  private returnUrl: string;

  id: string;
  meses = [
  {
    val: 1,
    mes: 'Enero'
  },
  {
    val: 2,
    mes: 'Febrero'
  },
  {
    val: 3,
    mes: 'Marzo'
  },
  {
    val: 4,
    mes: 'Abril'
  },
  {
    val: 5,
    mes: 'Mayo'
  },
  {
    val: 6,
    mes: 'Junio'
  },
  {
    val: 7,
    mes: 'Julio'
  },
  {
    val: 8,
    mes: 'Agosto'
  },
  {
    val: 9,
    mes: 'Septiembre'
  },
  {
    val: 10,
    mes: 'Octubre'
  },
  {
    val: 11,
    mes: 'Nomviembre'
  },
  {
    val: 12,
    mes: 'Diciembre'
  },
];
  curmes = 5;
  vchart: any;
  getdata: any;
  public barChartOptions: any = {
    //scaleShowVerticalLines: false,
    responsive: true,
    legend: { display: false },
    title: {
      display: true,
      text: 'Pronosticos del mes.'
    },
    scales: {
      xAxes: [{
        display: true,
        ticks: {
          min: 0,
          beginAtZero: true,
          max: 50
        }
      }],
      yAxes: [{
        display: true,
        //minBarLength: 0,
        ticks: {
          //min: 0,
          //beginAtZero: true,
          //max: 100
        }
      }],
    },
    scaleStartValue : 0
  };


  constructor(
    private formBuilder: FormBuilder,
    private rService: ReportesService,

  ) { }

  ngOnInit() {
    this.loadData(this.curmes);
  }

  loadData( id: any) {

    this.rService.getData(parseInt(id, 0))
      .subscribe((data: any) => {
        //console.log(data);
        //this.barChartLabels = data.results.data.data.labels;
        //this.barChartLabels = ['animales', 'Universidad']
        //this.barChartData = data.results.data.data;
        //this.getdata = data.results.results;
        this.vchart = new Chart('canvas',
          {
            type: 'line',
            data: data.results.data.data,
            options: this.barChartOptions
          }
        );


      });

  }

  loadAllData() {

    this.rService.getAllData()
      .subscribe((data: any) => {
        //console.log(data);
        //this.barChartLabels = data.results.data.data.labels;
        //this.barChartLabels = ['animales', 'Universidad']
        //this.barChartData = data.results.data.data;
        //this.getdata = data.results.results;
        this.vchart = new Chart('canvas',
          {
            type: 'line',
            data: data.results.data.data,
            options: this.barChartOptions
          }
        );


      });

  }

}
