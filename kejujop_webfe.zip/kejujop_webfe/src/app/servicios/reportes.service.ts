import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportesService {

  url = 'data';

  constructor(private http: HttpClient) { }



  getData(mes: any) {
    const reqHeader = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8;', 'No-Auth': 'True'});
    return this.http.get(environment.resturlapi + '/' + this.url + '/getdata/' + mes, {headers: reqHeader});
  }
  getAllData() {
    const reqHeader = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8;', 'No-Auth': 'True'});
    return this.http.get(environment.resturlapi + '/' + this.url + '/getalldata', {headers: reqHeader});
  }

}
