export const environment = {
  production: true,
  base: '/',
  resturl: 'http://localhost/integrador2019',
  resturlapi: 'http://localhost/integrador2019/rest',
  ipurl: 'http://ipinfo.io/json',

};
