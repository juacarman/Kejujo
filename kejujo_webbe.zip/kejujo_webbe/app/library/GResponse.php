<?php
//namespace PLApp\Library;
/**
 * Created by PhpStorm.
 * User: juacar01
 * Date: 24/05/15
 * Time: 12:30 PM
 */
//use PLApp\Models;


class GResponse extends \Phalcon\Mvc\User\Component {

    public static function json($arr, $code){

        $response = new \Phalcon\Http\Response();
        $response->setStatusCode($code, "OK");
        $response -> setHeader('Access-Control-Allow-Origin', '*');
        $response -> setHeader('Access-Control-Allow-Headers', 'X-Requested-With,Authorization,X-Accept-Charset,X-Accept,Content-Type,X-Access-Token,X-CSRF-Token');
        $response->setContentType('application/json', 'UTF-8');
        $response->setContent(json_encode($arr,JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK));

        return $response;
    }

    public static function Forbidden(){
        $response = new \Phalcon\Http\Response();
        $response->setStatusCode(403, "Forbidden");
        $response->send();
        die();
    }






}