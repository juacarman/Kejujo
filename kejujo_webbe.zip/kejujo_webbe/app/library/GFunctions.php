<?php
//namespace PLApp\Library;
use \Phalcon\Mvc\User\Component;
//use PLApp\Models;

//use PLApp\Models\Usuarios;
//use PLApp\Models\Usuariossesions;
//use PLApp\Models\Empresas;

//use Rhumsaa\Uuid\Uuid;
//use Rhumsaa\Uuid\Exception\UnsatisfiedDependencyException;



use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;
/**
 * Passwords
 *
 * Helper apra crear y comprobar passwords
 */
class GFunctions extends \Phalcon\Mvc\User\Component
{


    public static function genrandomcode(){
        $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $cad = "";
        for($i=0;$i<10;$i++) {
            $cad .= substr($str,rand(0,35),1);
        }
        return $cad;
    }

    public static function genjoorandomcode(){
        $str = "abcdefghijklmnopqrstvwxyz";
        $cad = "";
        for($i=0;$i<32;$i++) {
            $cad .= substr($str,rand(0,25),1);
        }
        return $cad;
    }

    public static function create_joopassword($pass, $salt = '')
    {

        if($salt == ''){
            $lsalt	= md5(mt_rand());
        }
        else{
            $lsalt	= $salt;
        }
        $encrypt = md5($pass.$lsalt);
        if($salt == ''){
            return $encrypt.':'.$lsalt;
        }
        else{
            return $encrypt;
        }
    }



    public static function generateSigla($empnom){
        $strRes = '';
        $nombre = strtolower(str_replace(" ", "", $empnom));
        if (strlen($nombre) > 6) {
            $strRes = substr($nombre, 0, 6);
        } else {
            $strRes = $nombre;
        }
        $ind = 1;
        $eind = false;
        while (!$eind) {
            $tmpemp = PosEmpresas::count("emp_sigla = '" .$strRes . $ind . "'");
            //echo var_dump($tmpemp);
            if($tmpemp<=0){
                $strRes.=$ind;
                $eind = true;
                //break;
            }
            $ind++;
        }

        return $strRes;

    }


    public static function getusernamedisp($nombre, $apellido){
        $tmpnom = explode(" ",$nombre);
        $tmpape = explode(" ", $apellido);
        $tmpusername = $tmpnom[0] . "." . $tmpape[0];

        $usernamedisponible = false;
        $count=99999;
        $i=1;
        //$tmpusername = $tmpusername.$i;
        $username='';
        while(!$usernamedisponible){
            $R = rand(1,99999);
            $fusername = $tmpusername.$i;
            $count = Usuarios::count("username = '$fusername'");
            //$count = $this->buscarcountUserName($tmpusername.$R);
            if($count==0){
                $username =$fusername;
                $usernamedisponible = true;

            }
            $i++;
        }
        return $username;

    }


    public static function createUUID()
    {

        /*$res = Globalmysqlfunctions::getNewUUID();

        return $res[0]['uuid'];*/
        $uuid1 = Uuid::uuid1();
        return $uuid1->toString();


    }
    public static function newRandomPassword(){
        $str = "abcdefghijklmnopqrstvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        $cad = "";
        for($i=0;$i<10;$i++) {
            $cad .= substr($str,rand(0,60),1);
        }
        $npass = $cad;
        return $npass;
    }


    public static function encrypt($pure_string) {
        $encryption_key = "*jmchaliciajuancho1981";



        $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $encrypted_string = mcrypt_encrypt(MCRYPT_BLOWFISH, $encryption_key, utf8_encode($pure_string), MCRYPT_MODE_ECB, $iv);
        return $encrypted_string;
    }

    /**
     * Returns decrypted original string
     */
    public static function decrypt($encrypted_string) {
        $encryption_key = "*jmchaliciajuancho1981";


        $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
        $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
        $decrypted_string = mcrypt_decrypt(MCRYPT_BLOWFISH, $encryption_key, $encrypted_string, MCRYPT_MODE_ECB, $iv);
        return $decrypted_string;
    }

    public static function calculaedad( $fecha ) {
        list($Y,$m,$d) = explode("-",$fecha);
        return( date("md") < $m.$d ? date("Y")-$Y-1 : date("Y")-$Y );
    }

    public static function time_ago( $date )
    {
        if( empty( $date ) )
        {
            return "No date provided";
        }

        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");

        $lengths = array("60","60","24","7","4.35","12","10");

        $now = time();

        $unix_date = strtotime( $date );

        // check validity of date

        if( empty( $unix_date ) )
        {
            return "Bad date";
        }

        // is it future date or past date
        $difference=0;
        if( $now > $unix_date )
        {
            $difference = $now - $unix_date;
            $tense = "ago";
        }
        else
        {
            $difference = $unix_date - $now;
            $tense = "from now";
        }

        $segundos=$difference;
        $minutos=$segundos/60;
        $horas=$segundos/(60*60);
        $dias=$segundos/(60*60*24);
        $meses=$segundos/(60*60*24*30);
        $anos=$segundos/(60*60*24*365);
//echo $segundos . ' minutos ' . $minutos . ' ' . $diference;
        /*
           prefixAgo: "hace",
           prefixFromNow: "dentro de",
           suffixAgo: "",
           suffixFromNow: "",
           seconds: "menos de un minuto",
           minute: "un minuto",
           minutes: "unos %d minutos",
           hour: "una hora",
           hours: "%d horas",
           day: "un día",
           days: "%d días",
           month: "un mes",
           months: "%d meses",
           year: "un año",
           years: "%d años"

         */

        $salida='';

        if ($segundos < 45) $salida = "hace menos de un minuto";
        elseif($segundos > 45 && $segundos <= 90) $salida = "hace 1 minuto.";
        elseif($segundos > 90 && $minutos <=  45) $salida = "hace unos ". floor($minutos) ." minutos.";
        elseif($minutos > 45 && $minutos <= 90) $salida = "hace 1 hora";
        elseif($minutos > 90 && $horas <= 24) $salida = "hace ". floor($horas) ." horas.";
        elseif($horas > 24 && $horas <= 42) $salida = "hace 1 día.";
        elseif($horas > 42 && $dias <= 30) $salida = "hace ". floor($dias) ." días.";
        elseif($dias > 30 && $dias <= 40) $salida = "hace 1 mes.";
        elseif($dias > 40 && $dias <= 365) $salida = "hace ". floor($meses) ." meses.";
        elseif($dias > 365 && $anos <= 1.5) $salida = "hace 1 año.";
        elseif($anos > 1.5) "hace ". math.floor($anos) ." meses.";

        return $salida;




        /*


            for( $j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++ )
            {
                $difference /= $lengths[$j];
            }

            $difference = round( $difference );

            if( $difference != 1 )
            {
                $periods[$j].= "s";
            }

            return "$difference $periods[$j] {$tense}";*/

    }


    public static function createToken($userid){

        $di = \Phalcon\DI::getDefault();
        $config = $di['config'];

        $authtok = new \stdClass();
        $authtok -> usuario = self::getUserdata($userid);
        $authtok -> iat = strtotime('now');
        $authtok -> exp = strtotime('+1 hour');

        //$authtoken = JWT::encode($authtok, $this -> config -> application -> cryptSalt);
        $authtoken = \Firebase\JWT\JWT::encode($authtok, $config->application->app_key);
        //$authstoken = array('token' => $authtoken);

        return $authtoken;

    }

    public static function getUserdata($userid, $ucolumns=array()){



        if(count($ucolumns) ==0){
            $ucolumns = array('usuid','ususuuid','usunom','usufullnom','usufacpnom','usufacsnom','usufacpape','usufacsape','usucountry','usuimg','usufecnac','ususexo','usumail','usulogintype','usufecreg','usufecupd','usustatus','usuusereg','usulastlogin','usurole', 'usuprofimgid',"usupt", "usuisdocente" );
            $ucolumns = array('usu_idusuario','usu_p_nombre','usu_s_nombre','usu_p_apellido','usu_s_apellido','usu_role','usu_estado','usu_idimagen','usu_habilitado','usu_created_at','usu_updated_at' );

        }
        $user = PosUsuarios::findFirstByUsu_idusuario($userid);
        $arresp = array();
        $arresp = array_merge($arresp,$user -> toArray($ucolumns));

        if ($user->usu_idimagen  ) {
            //$empresa = Empresas::findFirstByEmpid($user -> usuempid);
            //$empresa -> empuuid = $empresa -> empsuuid;
            $img = $user->getPosImagenes();
            //$img->imguuid = $img->imgsuuid;
            $arresp = array_merge($arresp, array( "profimg"=> $img -> toArray(array("img_surl","img_mdsurl","img_xssurl"))));
        }
        $empresas= $user->getEmpresas();

        $arremp= array();
        foreach ($empresas as $emp){
            $tarray = array(
                "emp_idempresa" => $emp->emp_idempresa,
                "emp_nombre" => $emp->emp_nombre,
                "emp_sigla" => $emp->emp_sigla,
            );
            $tarray = $emp->toArray(array("emp_idempresa","emp_nombre","emp_sigla"));

            $temp = PosEmpresas::findFirstByEmp_idempresa($emp->emp_idempresa);
            $pdvs = $temp->getPosPuntosDeVenta();
            $arrpdvs = array();
            foreach ($pdvs as $pdv){
                $tpdv = $pdv->toArray(array("pdv_idpuntodeventa","pdv_razon_social"));
                $cajas = $pdv->getPosCajas();
                $tpdv = array_merge($tpdv, array("cajas"=>$cajas->toArray(array("caj_idcaja", "caj_nombre"))));
                $ubicaciones = $pdv->getPosUbicaciones();
                $tpdv = array_merge($tpdv, array("ubicaciones"=>$ubicaciones->toArray(array("ubi_idubicacion", "ubi_nombre"))));
                 array_push($arrpdvs,$tpdv);

            }
            $tarray = array_merge($tarray,array( "tiendas"=>$arrpdvs));
            $bods = $temp->getPosBodegas();
            $tarray = array_merge($tarray,array( "bodegas"=>$bods->toArray(array("bod_idbodega", "bod_nombre"))));


            array_push($arremp,$tarray);



        }


        $arresp = array_merge($arresp, array( "empresas"=>$arremp));

        return $arresp;
    }
    public static function normalizeString($str){
        $logger = new Phalcon\Logger\Adapter\File("test.log");
        //$logger->log("inicia  salvar");
        switch(mb_detect_encoding($str)){
            case 'UTF-8':
                return utf8_encode($str);
            case 'ASCII':
                return utf8_encode($str);
            default:
                // $logger->log("No reconocido ".mb_detect_encoding($str));
                return utf8_encode($str);
        }


    }

    public static function log($str){
        $logger = new Phalcon\Logger\Adapter\File(APP_PATH."/logs/application.log");
        //empieza la transacción
        $logger->begin();

//añadimos los mensajes, los cuáles permanecen en memoria
        $logger->log($str);
        //$logger->error("Log de error");

//guardamos los logs finalmente en el archivo custom.log
        $logger->commit();


    }



    public static function getIp($request){
        $ip='';
        $ip = $request->getClientAddress( true);
        if($ip=='127.0.0.1' ||strpos($ip, '192.168.') ===false){
            $ip ='190.147.200.191';
        }
        return $ip;

    }
    public static function uploadImageFromURL($url, $presset, $usureg){


        \Cloudinary::config(array(
            "cloud_name" => _COUDINARY_CLOUD_NAME,
            "api_key" => _CLOUDINARY_API_KEY,
            "api_secret" => _CLOUDINARY_API_SECRET
        ));

        $imgres = \Cloudinary\Uploader::upload($url, array("upload_preset" => $presset));
        $imgobj = json_decode(json_encode($imgres), FALSE);


        $imgpublicid = $imgobj->public_id;
        $imgsignature = $imgobj->signature;
        $imgversion = $imgobj->version;
        $imgwidth = $imgobj->width;
        $imgheight = $imgobj->height;
        $imgformat = $imgobj->format;
        $imgbytes = $imgobj->bytes;
        $imgurl = $imgobj->url;
        $imgsurl = $imgobj->secure_url;
        $imgmdurl = $imgobj->eager[0]->url;
        $imgmdsurl = $imgobj->eager[0]->secure_url;
        $imgxsurl = $imgobj->eager[1]->url;
        $imgxssurl = $imgobj->eager[1]->secure_url;


        $iuuid = str_replace('-', '', self::createUUID());
        $img = new Mediaimages();
        $img->imguuid = pack("H*", $iuuid);
        $img->imgsuuid = $iuuid;
        // $img->imgempid = $ltoken->usuario->usuempid;
        $img->imgusureg =$usureg;
        //$img->imgtype=1;
        $img->imgpublicid = $imgpublicid;
        $img->imgsignature = $imgsignature;
        $img->imgformat = $imgformat;
        $img->imgbytes = $imgbytes;
        $img->imgversion = $imgversion;
        $img->imgwidth = $imgwidth;
        $img->imgheight= $imgheight;
        $img->imgurl = $imgurl;
        $img->imgsurl = $imgsurl;
        $img->imgmdurl = $imgmdurl;
        $img->imgmdsurl = $imgmdsurl;
        $img->imgxsurl = $imgxsurl;
        $img->imgxssurl = $imgxssurl;
        $img->save();


        $imagen = Mediaimages::findFirstByImguuid(pack("H*", $iuuid));

        return $imagen;








    }

    public static function texttourl($text){
        $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
        preg_match($reg_exUrl, $text, $url);
        return preg_replace($reg_exUrl, "<a href=".$url[0].">".$url[0]."</a> ", $text);


        $reg_exUrl = '/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/';

        return preg_replace($reg_exUrl, '<a href="{$url[0]}" target="_blank">{$url[0]}</a> ', $text);

        $text = html_entity_decode($text);
        $text = " ".$text;
        $text = preg_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_+.~#?&//=]+)',
            '<a href="\1">\1</a>', $text);
        $text = preg_replace('(((f|ht){1}tps://)[-a-zA-Z0-9@:%_+.~#?&//=]+)',
            '<a href="\1">\1</a>', $text);
        $text = preg_replace('([[:space:]()[{}])(www.[-a-zA-Z0-9@:%_+.~#?&//=]+)',
            '\1<a href="http://\2">\2</a>', $text);
        $text = preg_replace('([_.0-9a-z-]+@([0-9a-z][0-9a-z-]+.)+[a-z]{2,3})',
            '<a href="mailto:\1">\1</a>', $text);
        return $text;
    }

    public static function validarToken($request, $response, $obj){
       /* $di = \Phalcon\DI::getDefault();
        $config = $di['config'];*/
        $headers = $request->getHeaders();

        if(!isset($headers["Authorization"]) || empty($headers["Authorization"]))
        {
            $response->setStatusCode(403, "Forbidden");
            $response->send();
            die();
        }



        $htoken = trim(explode(" ", $headers["Authorization"])[1]);

        try{
            $ltoken = \Firebase\JWT\JWT::decode($htoken, $obj->config->application->app_key, array('HS256'));
            return $ltoken;
        }
        catch(\Firebase\JWT\ExpiredException $e){
            if($e->getMessage()=='Expired token'){
                $response->setStatusCode(401, "Unauthorized");
                $response->send();
            }
            die();
        }
    }
    public static function validarTokenOne($tis){
        /* $di = \Phalcon\DI::getDefault();
         $config = $di['config'];*/
        $headers = $tis->request->getHeaders();

        //print_r($headers, false);
        if(!isset($headers["Authorization"]) || empty($headers["Authorization"]))
        {
            $tis->response->setStatusCode(403, "Forbidden");
            $tis->response->send();
            die();
        }



        $htoken = trim(explode(" ", $headers["Authorization"])[1]);

        try{
            $ltoken = \Firebase\JWT\JWT::decode($htoken, $tis->config->application->app_key, array('HS256'));
            //GFunctions::log('Token '.$htoken);
            return $ltoken;
        }
        catch(\Firebase\JWT\ExpiredException $e){
            if($e->getMessage()=='Expired token'){
                GFunctions::log('Token Expiro '.$htoken);
                $tis->response->setStatusCode(401, "Unauthorized");
                $tis->response->send();
            }
            die();
        }
    }

    public static function nuevoToken($tis){
        /* $di = \Phalcon\DI::getDefault();
         $config = $di['config'];*/
        $headers = $tis->request->getHeaders();

        //print_r($headers, false);
        if(!isset($headers["Authorization"]) || empty($headers["Authorization"]))
        {
            $tis->response->setStatusCode(403, "Forbidden");
            $tis->response->send();
            die();
        }
        $htoken = trim(explode(" ", $headers["Authorization"])[1]);
        try{
            $ltoken = \Firebase\JWT\JWT::decode($htoken, $tis->config->application->app_key, array('HS256'));

            //$webtkn = $ltoken->session->webtkn;
            //$idusuario = $ltoken->session->idusuario;
            //$expirewebtkn =$ltoken->session->expirewebtkn;
            $tknidsession =$ltoken->session->idsession;

            /*if ($expirewebtkn+(60*5)< time()) {
                $tis->response->setStatusCode(401, "Unauthorized");
                $tis->response->send();
                die();
            }*/


            $lsession = \Inclusive\Models\Sesion::findFirst($tknidsession);
            $usuario = $lsession->getUsuario();

            $fechaL = time();
            $fechaExpire = strtotime('+1 hour');

            $session_data = array(
                "idsession" => $lsession->idsession,
                "user_agent" => $tis->request->getHeader("User-Agent") ,
                "regdate"=>$fechaL
            );
            $token = array(
                "session" => $session_data,
                "iat" => $fechaL,
                "exp" => $fechaExpire
            );
            $authtoken = \Firebase\JWT\JWT::encode($token, $tis->config->application->app_key);

            $session_data = array(
                "idsession" => $lsession->idsession,
                "idusuario" => $usuario->idusuario,
                "webtkn"=> $authtoken,
                "expirewebtkn" => $fechaExpire
            );
            $token = array(
                "session" => $session_data,
                "iat" => $fechaL
            );
            $refreshtoken = \Firebase\JWT\JWT::encode($token, $tis->config->application->app_key);

            $lsession->sesauthtoken=$refreshtoken;
            $lsession->sesrefreshtoken=$refreshtoken;
            if(!$lsession->save()){
                foreach ($lsession->getMessages() as $message) {
                    $erros[] = $message -> getMessage();
                }
                $resp['errors'] = $erros;
            }





            return $refreshtoken;
        }
        catch(\Firebase\JWT\ExpiredException $e){
            if($e->getMessage()=='Expired token'){
                $tis->response->setStatusCode(401, "Unauthorized");
                $tis->response->send();
            }
            die();
        }
    }

    public static function Upload($upload, $idempresa, $usuarioRegistrador){

        //$upload->moveTo(_UPLOAD_FILE_PATH.'/' . $upload->getName());

        $imagen = new PosImagenes();
        $imagen->img_idempresa=$idempresa; //cambiar
        $temp = explode(".", $upload->getName());
        $newfilename = $idempresa . '_' .$usuarioRegistrador->usu_idusuario . '_' . time() . '.' . end($temp);
        $finalpath =_UPLOAD_FILE_PATH.'/' . $newfilename;
        $upload->moveTo($finalpath);
        $imagen->img_local_file_path = realpath ($finalpath);
        $imagen->img_presset = "profimagen";

        if(!$imagen -> save()){
            foreach ($imagen->getMessages() as $message) {
                $erros[] = $message -> getMessage();
            }
            $result['errors'] = $erros;
            $result['status'] = false;

            return null;


        }
        return $imagen;

    }

    public static function get_data_fromUrl($url) {
        $ch = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }




}