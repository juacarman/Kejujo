<?php

class DataController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {

    }
    public function getDataAction(){
        $resp = array('status' => false, 'errors' => array());


        $filter = new \Phalcon\Filter();
        $id = $this -> dispatcher -> getParam('mes');
        $id = $filter -> sanitize($id, array('int'));

        $ardata = array();

        $arlabels = array();


        $data = $this->modelsManager->createBuilder()
            ->columns([
                // Fetching only desired columns (prefered way)
                'DATE_FORMAT(d.fecha, \'%Y-%m-%d\') as fecha',
                'd.prono',
            ])
            ->from(['d' => 'Integrador2019\Models\datos'])
            ->where("MONTH(d.fecha) =  :id: and YEAR(d.fecha)= 2019 ", ['id'=> $id])
            //->groupBy('u.idusuario, u.usunombre')
            ->orderBy('d.fecha asc')
            ->getQuery()->execute();

        $ardates = array();
        $arseries= array();
        $arlabels= array();

        $arcdata = array();
        $arcdatar = array();


        foreach ($data as $row){
            array_push($arlabels, $row->fecha);
            array_push($arcdata, $row->prono);
        }
        array_push($arseries, array("data"=>$arcdata, "label"=>"Pronostico"));


        $arcdatar = array_merge($arcdatar,
            array(
                "data"=>array(
                    "labels"=>$arlabels,
                    "datasets"=>$arseries
                ),

            )
        );

        $resp['results'] = array("data"=>$arcdatar);
        $resp['status'] = true;
        $resp['errors'] = array();
        return GResponse::json($resp, 200);
    }
    public function getAllDataAction(){
        $resp = array('status' => false, 'errors' => array());


        $filter = new \Phalcon\Filter();
        $id = $this -> dispatcher -> getParam('mes');
        $id = $filter -> sanitize($id, array('int'));

        $ardata = array();

        $arlabels = array();


        $data = $this->modelsManager->createBuilder()
            ->columns([
                // Fetching only desired columns (prefered way)
                'DATE_FORMAT(d.fecha, \'%Y-%m-%d\') as fecha',
                'd.prono',
            ])
            ->from(['d' => 'Integrador2019\Models\datos'])
            ->where("YEAR(d.fecha)= 2019 ")
            //->groupBy('u.idusuario, u.usunombre')
            ->orderBy('d.fecha asc')
            ->getQuery()->execute();

        $ardates = array();
        $arseries= array();
        $arlabels= array();

        $arcdata = array();
        $arcdatar = array();


        foreach ($data as $row){
            array_push($arlabels, $row->fecha);
            array_push($arcdata, $row->prono);
        }
        array_push($arseries, array("data"=>$arcdata, "label"=>"Pronostico"));


        $arcdatar = array_merge($arcdatar,
            array(
                "data"=>array(
                    "labels"=>$arlabels,
                    "datasets"=>$arseries
                ),

            )
        );

        $resp['results'] = array("data"=>$arcdatar);
        $resp['status'] = true;
        $resp['errors'] = array();
        return GResponse::json($resp, 200);
    }

}

