<?php

$router = $di->getRouter();
$apiprefix = '/rest';
// Define your routes here
$controller ='Data';
$urlprefix ='data';
$urlsubprefix ='data';

$router->add($apiprefix.'/'.$urlprefix.'/getdata/{mes:[0-9]+}', array(
    'controller' => $controller,
    'action' => 'getData'
))->via(array("GET"));
$router->add($apiprefix.'/'.$urlprefix.'/getalldata', array(
    'controller' => $controller,
    'action' => 'getAllData'
))->via(array("GET"));


$router->handle();
