<?php


$loader = new \Phalcon\Loader();

/**
 * We're a registering a set of directories taken from the configuration file
 */
$loader->registerNamespaces(
    [
        'Integrador2019\Models'      => $config->application->modelsDir,
    ]
);
$loader->registerDirs(
    [
        $config->application->controllersDir,
        $config->application->modelsDir,
        $config->application->libraryDir,
        //$config->application->modelsExtDir,
    ]
);
$loader->register();

/*
$loader = new \Phalcon\Loader();
*/
/**
 * We're a registering a set of directories taken from the configuration file
 */
/*$loader->registerDirs(
    [
        $config->application->controllersDir,
        $config->application->modelsDir
    ]
)->register();
*/